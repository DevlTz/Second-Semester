#include <chrono>
#include <functional>
#include <iostream>
#include <random>
#include <vector>
#include <string>
#include <fstream>
#include <cstdlib>

#include "lib/sorting.h"

using value_type = unsigned long int;
using size_type = long int;
using duration_t = std::chrono::duration<double>;
using Comparator = std::function<bool(const value_type &, const value_type &)>;
using str = std::string;

constexpr bool compare(const value_type &a, const value_type &b) { return a < b; }

enum Scenario
{
  NON_DECREASING,
  NON_GROWING,
  ALL_RANDOM,
  SORTED_25,
  SORTED_50,
  SORTED_75
};

struct RunningOptions
{
  constexpr static size_t min_sample_sz{64};
  constexpr static size_t max_sample_sz{10000};
  constexpr static int n_samples{5};
  constexpr static short n_runs{3};

  static size_type sample_step() { return static_cast<float>(max_sample_sz - min_sample_sz) / (n_samples - 1); }
};

template <typename T>
class DataSet
{
private:
  std::vector<T> src;
  size_t max_src_sz, limit_src_sz;
  std::vector<Scenario> scenarios;
  size_t current_scenario;

public:
  DataSet(std::initializer_list<Scenario> scenarios, size_t max_src_sz, size_t limit_src_sz)
      : scenarios(scenarios), max_src_sz(max_src_sz), limit_src_sz(limit_src_sz), current_scenario(0)
  {
    generate_src();
  }

  void generate_src()
  {
    src.resize(max_src_sz);

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> distrib(0, 100);

    for (auto &e : src)
      e = distrib(gen);
  }

  void next()
  {
    if (current_scenario < scenarios.size() - 1)
      ++current_scenario;
    else
      current_scenario = scenarios.size();
  }

  auto begin() { return src.data(); }

  auto end() { return (src.data() + limit_src_sz); }

  bool has_ended() { return current_scenario >= scenarios.size(); }

  void reset_limit_src() { limit_src_sz = RunningOptions::min_sample_sz; }

  str get_current_scenario_name()
  {
    switch (scenarios[current_scenario])
    {
    case NON_DECREASING:
      return "NON_DECREASING";
    case NON_GROWING:
      return "NON_GROWING";
    case SORTED_25:
      return "SORTED_25";
    case SORTED_50:
      return "SORTED_50";
    case SORTED_75:
      return "SORTED_75";
    default: // ALL_RANDOM
      return "ALL_RANDOM";
    }
  }

  void update_limit_src(size_t step)
  {
    if (limit_src_sz + step <= src.size())
    {
      limit_src_sz += step;
    }
    else
    {
      limit_src_sz = src.size(); // Limita ao tamanho máximo.
    }
  }
  size_t size() const { return limit_src_sz; }
};

template <typename T, typename C>
class SortingCollection
{
private:
  std::vector<std::pair<std::function<void(T *, T *, C)>, std::string>> algorithms;
  size_t current_algorithm;

public:
  SortingCollection(std::initializer_list<std::pair<std::function<void(T *, T *, C)>, std::string>> algs)
      : algorithms(algs), current_algorithm(0) {}

  void next()
  {
    if (current_algorithm < algorithms.size() - 1)
      ++current_algorithm;
    else
      current_algorithm = algorithms.size();
  }

  void reset() { current_algorithm = 0; }

  auto has_ended() { return current_algorithm >= algorithms.size(); }

  auto get_cur_alg() { return algorithms[current_algorithm].first; }

  str get_cur_alg_name() { return algorithms[current_algorithm].second; }
};

int main(int argc, char *argv[])
{
  std::cout << ">>> STARTING PROGRAM <<<\n\n";

  // Arquivo CSV para salvar os resultados.
  std::ofstream csv_file("sorting_results_40000.csv");
  if (!csv_file.is_open())
  {
    std::cerr << "Erro ao abrir arquivo para escrita.\n";
    return EXIT_FAILURE;
  }

  // Cabeçalho do CSV.
  csv_file << "Scenario,Algorithm,Sample Size,Mean Duration (s)\n";

  // Scenarios for execution.
  DataSet<value_type> dataset{
      {NON_DECREASING, NON_GROWING, ALL_RANDOM, SORTED_25, SORTED_50, SORTED_75},
      RunningOptions::max_sample_sz,
      RunningOptions::min_sample_sz};

  // Algorithms to be executed.
  SortingCollection<value_type, Comparator> algorithms{
      {sa::insertion<value_type, Comparator>, "Insertion Sort"},
      {sa::selection<value_type, Comparator>, "Selection Sort"},
      {sa::bubble<value_type, Comparator>, "Bubble Sort"},
      {sa::quick<value_type, Comparator>, "Quick Sort"},
      {sa::shell<value_type, Comparator>, "Shell Sort"},
      {sa::mergesort<value_type, Comparator>, "Merge Sort"}};

  while (!dataset.has_ended())
  {
    auto scenario{dataset.get_current_scenario_name()};
    std::cout << "\n>>> Current Scenario: " << scenario << "\n";

    auto sample_step{RunningOptions::sample_step()};
    auto n_samples{RunningOptions::n_samples};

    std::cout << "\tNumber of samples to be tested = " << n_samples << '\n';
    std::cout << "\tSample step = " << sample_step << "\n\n";

    // Reinicia o limite da amostra para o tamanho mínimo no início de cada cenário
    dataset.reset_limit_src();

    for (auto ns{0}; ns < n_samples; ++ns)
    {
      std::cout << "\t>>> Sample size: " << dataset.size() << '\n';

      while (!algorithms.has_ended())
      {
        duration_t elapsed_time_mean{0.0};

        auto curr_sorting_alg{algorithms.get_cur_alg()};
        auto alg_name{algorithms.get_cur_alg_name()};
        auto n_runs{RunningOptions::n_runs};

        std::cout << "\t\tTesting " << alg_name << "...\n";

        for (auto ct_run{0}; ct_run < n_runs; ++ct_run)
        {
          auto start{std::chrono::steady_clock::now()};
          curr_sorting_alg(dataset.begin(), dataset.end(), compare);
          auto end{std::chrono::steady_clock::now()};

          duration_t diff{end - start};
          elapsed_time_mean = elapsed_time_mean + (diff - elapsed_time_mean) / static_cast<double>(ct_run + 1);
        }

        std::cout << "\t\tMean duration: " << elapsed_time_mean.count() << " seconds\n\n";

        // Escrevendo resultados no arquivo CSV.
        csv_file << scenario << ',' << alg_name << ',' << dataset.size() << ',' << elapsed_time_mean.count() << '\n';

        algorithms.next();
      }

      algorithms.reset();
      dataset.update_limit_src(sample_step);
    }

    dataset.next();
  }

  csv_file.close();
  std::cout << "\n\n>>> Results saved to sorting_results.csv\n";
  std::cout << ">>> FINISHING PROGRAM...\n";
  return EXIT_SUCCESS;
}
