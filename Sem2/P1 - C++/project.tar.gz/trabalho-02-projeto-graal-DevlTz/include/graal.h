/*!
 * @file graal.h
 * @brief Header file containing various algorithms for working with ranges.
 * 
 * This file includes implementations of algorithms such as finding minimum and maximum,
 * reversing a range, copying elements, and checking predicates over ranges.
 * 
 * @author Selan
 * @date April 6th, 2024
 */

#ifndef GRAAL_H
#define GRAAL_H

#include <utility>
using std::pair;

namespace graal {

/*!
 * Finds and returns a pair with the smallest and greatest elements in a range.
 *
 * @tparam Itr Iterator to the range.
 * @tparam Compare A regular comparison function. Comparison functor.
 *
 * @param first Pointer to the first element of the range we want to copy (inclusive).
 * @param last Pointer to the last element of the range we want to copy (exclusive).
 * @param cmp The comparison function that returns true if the first element is *less* than the
 * second.
 *
 * @return A pair of iterators pointing to the smallest and greatest elements.
 */
template <typename Itr, typename Compare>
std::pair<Itr, Itr> minmax(Itr first, Itr last, Compare cmp) {
  if (first == last) {
    return std::make_pair(first, first);
  }

  Itr min = first;
  Itr max = first;

  Itr target = first;

  while (target != last) {
    if (cmp(*target, *min)) {
      min = target;
    }
    if (!cmp(*target, *max)) {
      max = target;
    }
    target++;
  }

  return std::make_pair(min, max);
}

/*!
 * Reverses the elements in a bidirectional iterator range.
 *
 * @tparam BidirIt Bidirectional iterator type.
 *
 * @param first Pointer to the first element of the range.
 * @param last Pointer to the last element of the range (exclusive).
 */
template <class BidirIt> 
void reverse(BidirIt first, BidirIt last) {
  if (first == last) {
    return;
  }
  last--;

  for (; first < last; first++, last--) {
    std::swap(*first, *last);
  }
}

/*!
 * Copies elements from one range to another.
 *
 * @tparam InputIt Iterator type for the input range.
 *
 * @param first Pointer to the first element of the source range.
 * @param last Pointer to the last element of the source range (exclusive).
 * @param d_first Pointer to the first element of the destination range.
 * @return An iterator pointing to the end of the destination range.
 */
template <class InputIt> 
InputIt copy(InputIt first, InputIt last, InputIt d_first) {
  while (first != last) {
    *d_first = *first;
    first++;
    d_first++;
  }
  return d_first;
}

/*!
 * Finds the first element in a range that satisfies a predicate.
 *
 * @tparam InputIt Iterator type for the range.
 * @tparam UnaryPredicate Predicate type.
 *
 * @param first Pointer to the first element of the range.
 * @param last Pointer to the last element of the range (exclusive).
 * @param p Predicate function that returns true for the desired element.
 * @return An iterator pointing to the found element, or `last` if none is found.
 */
template <class InputIt, class UnaryPredicate>
InputIt find_if(InputIt first, InputIt last, UnaryPredicate p) {
  for (; first != last; first++) {
    if (p(*first)) {
      return first;
    }
  }
  return last;
}

/*!
 * Checks if all elements in a range satisfy a predicate.
 *
 * @tparam InputIt Iterator type for the range.
 * @tparam UnaryPredicate Predicate type.
 *
 * @param first Pointer to the first element of the range.
 * @param last Pointer to the last element of the range (exclusive).
 * @param p Predicate function.
 * @return True if all elements satisfy the predicate, false otherwise.
 */
template <class InputIt, class UnaryPredicate>
bool all_of(InputIt first, InputIt last, UnaryPredicate p) {
  for (; first != last; first++) {
    if (!p(*first)) {
      return false;
    }
  }
  return true;
}

/*!
 * Checks if any element in a range satisfies a predicate.
 *
 * @tparam InputIt Iterator type for the range.
 * @tparam UnaryPredicate Predicate type.
 *
 * @param first Pointer to the first element of the range.
 * @param last Pointer to the last element of the range (exclusive).
 * @param p Predicate function.
 * @return True if any element satisfies the predicate, false otherwise.
 */
template <class InputIt, class UnaryPredicate>
bool any_of(InputIt first, InputIt last, UnaryPredicate p) {
  for (; first != last; first++) {
    if (p(*first)) {
      return true;
    }
  }
  return false;
}

/*!
 * Checks if no element in a range satisfies a predicate.
 *
 * @tparam InputIt Iterator type for the range.
 * @tparam UnaryPredicate Predicate type.
 *
 * @param first Pointer to the first element of the range.
 * @param last Pointer to the last element of the range (exclusive).
 * @param p Predicate function.
 * @return True if no elements satisfy the predicate, false otherwise.
 */
template <class InputIt, class UnaryPredicate>
bool none_of(InputIt first, InputIt last, UnaryPredicate p) {
  for (; first != last; first++) {
    if (p(*first)) {
      return false;
    }
  }
  return true;
}

/*!
 * Compares two ranges for equality.
 *
 * @tparam InputIt1 Iterator type for the first range.
 * @tparam InputIt2 Iterator type for the second range.
 * @tparam Equal Equality comparison function.
 *
 * @param first1 Pointer to the first element of the first range.
 * @param last1 Pointer to the last element of the first range.
 * @param first2 Pointer to the first element of the second range.
 * @param eq Equality comparison function.
 * @return True if the ranges are equal, false otherwise.
 */
template <class InputIt1, class InputIt2, class Equal>
bool equal(InputIt1 first1, InputIt1 last1, InputIt2 first2, Equal eq) {
  for (; first1 != last1; first1++, first2++) {
    if (!eq(*first1, *first2)) {
      return false;
    }
  }
  return true;
}

/*!
 * Compares two ranges for equality with separate last iterators.
 *
 * @tparam InputIt1 Iterator type for the first range.
 * @tparam InputIt2 Iterator type for the second range.
 * @tparam Equal Equality comparison function.
 *
 * @param first1 Pointer to the first element of the first range.
 * @param last1 Pointer to the last element of the first range.
 * @param first2 Pointer to the first element of the second range.
 * @param last2 Pointer to the last element of the second range.
 * @param eq Equality comparison function.
 * @return True if the ranges are equal, false otherwise.
 */
template <class InputIt1, class InputIt2, class Equal>
bool equal(InputIt1 first1, InputIt1 last1, InputIt2 first2, InputIt2 last2, Equal eq) {
  for (; first1 != last1 && first2 != last2; first1++, first2++) {
    if (!eq(*first1, *first2)) {
      return false;
    }
  }
  return first1 == last1 && first2 == last2;
}

/*!
 * Removes consecutive duplicate elements from a range.
 *
 * @tparam InputIt Iterator type for the range.
 * @tparam Equal Equality comparison function.
 *
 * @param first Pointer to the first element of the range.
 * @param last Pointer to the last element of the range (exclusive).
 * @param eq Equality comparison function.
 * @return An iterator pointing to the end of the unique range.
 */
template <class InputIt, class Equal>
InputIt unique(InputIt first, InputIt last, Equal eq) {
  if (first == last) {
    return last;
  }
  InputIt target = first;

  for (InputIt it = first; it != last; it++) {
    InputIt check = first;

    while (check != it && !eq(*check, *it)) {
      check++;
    }
    if (check == it) {
      if (target != it) {
        *target = *it;
      }
      target++;
    }
  }
  return target;
}

/*!
 * Partitions a range based on a predicate, moving elements satisfying the predicate to the front.
 *
 * @tparam ForwardIt Forward iterator type.
 * @tparam UnaryPredicate Predicate type.
 *
 * @param first Pointer to the first element of the range.
 * @param last Pointer to the last element of the range (exclusive).
 * @param p Predicate function.
 * @return An iterator pointing to the first element of the second partition.
 */
template <class ForwardIt, class UnaryPredicate>
ForwardIt partition(ForwardIt first, ForwardIt last, UnaryPredicate p) {
  for (ForwardIt it = first; it != last; it++) {
    if (p(*it)) {
      std::swap(*first, *it);
      first++;
    }
  }
  return first;
}

}  // namespace graal.

#endif
