[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/6peShdKQ)
﻿# Análise Empírica de Algoritmos de Ordenação

## Apresentação

Nesse trabalho você terá a oportunidade de desenvolver algoritmos clássicos de
ordenação e realizar um experimento empírico com esses algoritmos.

Para a realização do experimento, é necessário o desenvolvimento de um sistema
computacional que permita a execução e coleta de dados de acordo com os
cenários experimentais apresentados no documento descritivo do projeto, o qual
pode ser encontrado [**aqui**](docs/sorting_algorithms.pdf).

Por fim, você precisará elaborar um relatório técnico completo, no qual você
apresenta o projeto que foi desenvolvido e tenta responder as perguntas de
pesquisa presentes no PDF de descrição do projeto.

Você precisa também fornecer algumas informações no arquivo [author.md](author.md),
indicando a autoria do trabalho e quais itens da tarefa foram realizados com
sucesso. 

## Código de suporte

O código fornecido neste repositório contém apenas sugestões de como você pode
organizar seus experimentos. Não é um código compilável e contém apenas trechos
de códigos (incompletos) e comentários.

A equipe é livre para usar ou não o código oferecido.
Isto é, se a equipe não desejar utilizar o código do repositório, ela 
pode removê-lo completamente e fazer sua própria implementação.

## Exemplo de Relatório

As instruções para a elaboração do relatório estão presentes no [documento
descritivo do projeto](docs/sorting_algorithms.pdf).

Na pasta [Exemplo-relatorio](docs/Exemplo-relatorio/) você vai encontrar
alguns arquivos no formato *Latex*, caso deseje utilizar esta ferramenta
para escrever o relatório.
Este formato segue o padrão ABNT e está formatado com a capa da UFRN.      

Para compilar o projeto e gerar o PDF, execute os seguintes comando na pasta
raiz do relatório:
```bash
$ pdflatex main.tex
$ bibtex main
$ pdflatex main.tex
$ pdflatex main.tex
```

## Submissão do Trabalho

Consulte o arquivo PDF com a [descrição do
trabalho](docs/sorting_algorithms.pdf) para saber como submeter seu trabalho.

--------
&copy; DIMAp/UFRN 2024.
