﻿# Identificação Pessoal

Preencha os dados abaixo para identificar a autoria do trabalho.

- Nome: *<Kauã do Vale Ferreira & Flavio Oliveira Silva Junior>*
- Email: *<kkvale27@gmail.com & flavinhoj78@gmail.com >*
- Turma: *<BCC - Segundo Semestre : 2024.1>*

# Indique quais algoritmos foram implementados nos experimentos

- [V] Insertion sort
- [V] Selection sort
- [V] Bubble sort
- [V] Shell sort
- [V] Quick sort
- [V] Merge sort
- [V] Radix sort

# Indique quais dos cenários de dados abaixo você conseguiu simular nos experimentos

- [V] todos randômicos
- [V] parcialmente ordenado (75%)
- [V] parcialmente ordenado (50%)
- [V] parcialmente ordenado (25%)
- [V] dados em ordem não-decrescente
- [V] dados em ordem não-crescente

# Escreva a quantidade de amostras coletadas por experimento

- Utilizei _XXX_ amostras por experimento

# Indique quais das perguntas abaixo foram respondidas no relatório

- [V] O que você descobriu de maneira geral.
- [V] Quais algoritmos são recomendados para quais cenários?
- [V] Como o algoritmo de decomposição de chave (radix) se compara com o melhor algoritmo baseado em _comparação_ de chaves?
- [V] É verdade que o _quick sort_, na prática, é mesmo mais rápido do que o _merge sort_?
- [V] Aconteceu algo inesperado nas medições? (por exemplo, picos ou vales nos gráficos) Se sim, por que?
- [V] Com base nos resultados empíricos, faça uma estimativa para os 7 algoritmos estudados de quanto tempo seria necessário para rodar uma amostra de $10^12$ elementos.
- [V] A análise empírica é compatível com a análise de complexidade matemática? Ou seja, você consegui ajustar uma curva compatível com a complexidade aos dados?

--------
&copy; DIMAp/UFRN 2024.
