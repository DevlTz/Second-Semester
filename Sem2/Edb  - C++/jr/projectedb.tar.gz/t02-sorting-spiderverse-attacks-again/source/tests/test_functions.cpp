#include "../lib/sorting.h"
#include <iostream>
#include <vector>
#include <string>
#include <functional> // std::less
#include <algorithm>  // std::is_sorted, std::sort, std::shuffle
#include <random>     // std::mt19937, std::random_device
#include <ctime>      // std::time

using namespace sa;
using namespace std;

template <typename T>
void printArray(T* first, T* last, const string& title) {
  cout << title << ": [";
  for (auto it = first; it != last; ++it) {
    cout << *it;
    if (it + 1 != last) cout << ", "; // Adiciona vírgula se não for o último elemento
  }
  cout << "]" << endl;
}

// Função para gerar arrays aleatórios
template <typename T>
void generateRandomArray(T* arr, size_t size, T minValue, T maxValue) {
  random_device rd;
  mt19937 gen(rd());
  uniform_int_distribution<T> dist(minValue, maxValue);

  for (size_t i = 0; i < size; ++i) {
    arr[i] = dist(gen);
  }

  // Embaralhar o array
  shuffle(arr, arr + size, gen);
}

// Função para gerar array parcialmente ordenado
template <typename T>
void generatePartiallySortedArray(T* arr, size_t size, double percentage) {
  generateRandomArray(arr, size, 0, 100); // Primeiro gera um array aleatório

  size_t sortedCount = static_cast<size_t>(size * percentage);
  sort(arr, arr + sortedCount); // Ordena uma parte do array
}

// Função para testar o Radix
template <typename T>
bool testSortingRadix(T* arr, size_t size, const string& testName) {
  cout << "Running test: " << testName << endl;

  T* originalArr = new T[size];
  copy(arr, arr + size, originalArr);

  printArray(arr, arr + size, "Before");
  radix(arr, arr + size);
  printArray(arr, arr + size, "After");

  // Verificar se o array está ordenado corretamente
  sort(originalArr, originalArr + size);
  bool passed = equal(arr, arr + size, originalArr);

  if (passed) {
    cout << "Test passed!" << endl;
  } else {
    cout << "Test failed!" << endl;
  }
  cout << endl;

  delete[] originalArr;
  return passed;
}

// Função para rodar os testes
template <typename T>
void runAllTestsRadix(const string& algorithmName, size_t randomSize) {
  bool allPassed = true;

  // Testes do algoritmo
  T arr1[] = {42, 15, 8, 23, 4, 16};
  allPassed &= testSortingRadix(arr1, sizeof(arr1) / sizeof(arr1[0]), algorithmName + " - Caso Geral");

  T arr2[] = {10, 20, 30, 40, 50, 60};
  allPassed &= testSortingRadix(arr2, sizeof(arr2) / sizeof(arr2[0]), algorithmName + " - Ordem Crescente");

  T arr3[] = {16, 15, 14, 13, 12, 11};
  allPassed &= testSortingRadix(arr3, sizeof(arr3) / sizeof(arr3[0]), algorithmName + " - Ordem Decrescente");

  T arr4[] = {5, 5, 5, 5, 5, 5};
  allPassed &= testSortingRadix(arr4, sizeof(arr4) / sizeof(arr4[0]), algorithmName + " - Todos Iguais");

  T arr5[] = {9, 2, 7, 3, 9, 5, 1, 4};
  allPassed &= testSortingRadix(arr5, sizeof(arr5) / sizeof(arr5[0]), algorithmName + " - Repetições Misturadas");

  T arr6[] = {};
  allPassed &= testSortingRadix(arr6, 0, algorithmName + " - Array Vazio");

  // Array aleatório
  T* randomArr = new T[15];  // Tamanho reduzido para 15 elementos
  generateRandomArray(randomArr, 15, 0, 100);
  allPassed &= testSortingRadix(randomArr, 15, algorithmName + " - Array Aleatório");
  delete[] randomArr;

  // Array parcialmente ordenado
  T* partiallySortedArr75 = new T[15];  // Tamanho reduzido para 15 elementos
  generatePartiallySortedArray(partiallySortedArr75, 15, 0.75);
  allPassed &= testSortingRadix(partiallySortedArr75, 15, algorithmName + " - Parcialmente Ordenado (75%)");
  delete[] partiallySortedArr75;

  T* partiallySortedArr50 = new T[15];  // Tamanho reduzido para 15 elementos
  generatePartiallySortedArray(partiallySortedArr50, 15, 0.50);
  allPassed &= testSortingRadix(partiallySortedArr50, 15, algorithmName + " - Parcialmente Ordenado (50%)");
  delete[] partiallySortedArr50;

  T* partiallySortedArr25 = new T[15];  // Tamanho reduzido para 15 elementos
  generatePartiallySortedArray(partiallySortedArr25, 15, 0.25);
  allPassed &= testSortingRadix(partiallySortedArr25, 15, algorithmName + " - Parcialmente Ordenado (25%)");
  delete[] partiallySortedArr25;

  // Resultado final
  cout << "==========================\n";
  if (allPassed) {
    cout << algorithmName << " passed all tests!\n";
  } else {
    cout << algorithmName << " failed some tests!\n";
  }
  cout << "==========================\n";
}

// Funções para execução de testes dos algoritmos
void testInsertionSort() {
  runAllTestsRadix<int>("Insertion Sort", 100);
}

void testSelectionSort() {
  runAllTestsRadix<int>("Selection Sort", 100);
}

void testBubbleSort() {
  runAllTestsRadix<int>("Bubble Sort", 100);
}

void testShellSort() {
  runAllTestsRadix<int>("Shell Sort", 100);
}

void testQuickSort() {
  runAllTestsRadix<int>("Quick Sort", 100);
}

void testMergeSort() {
  runAllTestsRadix<int>("Merge Sort", 100);
}

void testeRadixSort() {
  runAllTestsRadix<int>("Radix Sort", 100);
}

int main() {
  // Executa os testes para cada algoritmo
  cout << "==========================\n";
  cout << "Testing Sorting Algorithms\n";
  cout << "==========================\n";

  testInsertionSort();
  testSelectionSort();
  testBubbleSort();
  testShellSort();
  testQuickSort();
  testMergeSort();
  testeRadixSort();

  return 0;
}
