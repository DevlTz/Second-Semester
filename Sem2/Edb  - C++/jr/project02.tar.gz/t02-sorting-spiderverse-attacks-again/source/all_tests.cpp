#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN

#include <array>
#include <string>

#include "include/doctest.h"
#include "lib/sorting.h"

using type = unsigned int;
using str = std::string;

auto lt(type a, type b) { return a < b; }

/// INSERTION SORT TEST SUITE
TEST_SUITE(">>> Insertion Sort Algorithm Test Suite...")
{
    TEST_CASE("Sorting empty array:")
    {
        const type src_sz{0};
        std::array<type, src_sz> src{};
        str expected("[ ]");

        auto f{src.begin()}, l{src.end()};
        sa::insertion(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting array of unique elements:")
    {
        const type src_sz{5};
        std::array<type, src_sz> src{12, 12, 12, 12, 12};
        str expected("[ 12 12 12 12 12 ]");

        auto f{src.begin()}, l{src.end()};
        sa::insertion(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting all the elements of an array without repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 3, 4, 7, 6, 1, 5, 8, 10, 9};
        str expected("[ 1 2 3 4 5 6 7 8 9 10 ]");

        auto f{src.begin()}, l{src.end()};
        sa::insertion(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting all the elements of an array with repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 7, 4, 7, 6, 8, 5, 8, 10, 2};
        str expected("[ 2 2 4 5 6 7 7 8 8 10 ]");

        auto f{src.begin()}, l{src.end()};
        sa::insertion(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting part of the elements of an array without repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 4, 3, 7, 6, 1, 5, 8, 10, 9};
        str expected("[ 2 3 4 6 7 1 5 8 10 9 ]");

        auto f{src.begin()}, l{src.begin() + 5};
        sa::insertion(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting part of the elements of an array with repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 7, 4, 7, 6, 8, 5, 8, 10, 2};
        str expected("[ 2 4 6 7 7 8 5 8 10 2 ]");

        auto f{src.begin()}, l{src.begin() + 5};
        sa::insertion(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }
}
/// INSERTION SORT TEST SUITE

/// SELECTION SORT TEST SUITE
TEST_SUITE(">>> Selection Sort Algorithm Test Suite...")
{
    TEST_CASE("Sorting empty array:")
    {
        const type src_sz{0};
        std::array<type, src_sz> src{};
        str expected("[ ]");

        auto f{src.begin()}, l{src.end()};
        sa::selection(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting array of unique elements:")
    {
        const type src_sz{5};
        std::array<type, src_sz> src{12, 12, 12, 12, 12};
        str expected("[ 12 12 12 12 12 ]");

        auto f{src.begin()}, l{src.end()};
        sa::selection(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting all the elements of an array without repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 3, 4, 7, 6, 1, 5, 8, 10, 9};
        str expected("[ 1 2 3 4 5 6 7 8 9 10 ]");

        auto f{src.begin()}, l{src.end()};
        sa::selection(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting all the elements of an array with repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 7, 4, 7, 6, 8, 5, 8, 10, 2};
        str expected("[ 2 2 4 5 6 7 7 8 8 10 ]");

        auto f{src.begin()}, l{src.end()};
        sa::selection(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting part of the elements of an array without repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 4, 3, 7, 6, 1, 5, 8, 10, 9};
        str expected("[ 2 3 4 6 7 1 5 8 10 9 ]");

        auto f{src.begin()}, l{src.begin() + 5};
        sa::selection(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting part of the elements of an array with repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 7, 4, 7, 6, 8, 5, 8, 10, 2};
        str expected("[ 2 4 6 7 7 8 5 8 10 2 ]");

        auto f{src.begin()}, l{src.begin() + 5};
        sa::selection(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }
}
/// SELECTION SORT TEST SUITE

/// BUBBLE SORTE TEST SUITE
TEST_SUITE(">>> Bubble Sort Algorithm Test Suite...")
{
    TEST_CASE("Sorting empty array:")
    {
        const type src_sz{0};
        std::array<type, src_sz> src{};
        str expected("[ ]");

        auto f{src.begin()}, l{src.end()};
        sa::bubble(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting array of unique elements:")
    {
        const type src_sz{5};
        std::array<type, src_sz> src{12, 12, 12, 12, 12};
        str expected("[ 12 12 12 12 12 ]");

        auto f{src.begin()}, l{src.end()};
        sa::bubble(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting all the elements of an array without repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 3, 4, 7, 6, 1, 5, 8, 10, 9};
        str expected("[ 1 2 3 4 5 6 7 8 9 10 ]");

        auto f{src.begin()}, l{src.end()};
        sa::bubble(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting all the elements of an array with repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 7, 4, 7, 6, 8, 5, 8, 10, 2};
        str expected("[ 2 2 4 5 6 7 7 8 8 10 ]");

        auto f{src.begin()}, l{src.end()};
        sa::bubble(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting part of the elements of an array without repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 4, 3, 7, 6, 1, 5, 8, 10, 9};
        str expected("[ 2 3 4 6 7 1 5 8 10 9 ]");

        auto f{src.begin()}, l{src.begin() + 5};
        sa::bubble(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting part of the elements of an array with repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 7, 4, 7, 6, 8, 5, 8, 10, 2};
        str expected("[ 2 4 6 7 7 8 5 8 10 2 ]");

        auto f{src.begin()}, l{src.begin() + 5};
        sa::bubble(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }
}
/// BUBBLE SORTE TEST SUITE

/// SHELL SORT TEST SUITE
TEST_SUITE(">>> Shell Sort Algorithm Test Suite...")
{
    TEST_CASE("Sorting empty array:")
    {
        const type src_sz{0};
        std::array<type, src_sz> src{};
        str expected("[ ]");

        auto f{src.begin()}, l{src.end()};
        sa::shell(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting array of unique elements:")
    {
        const type src_sz{5};
        std::array<type, src_sz> src{12, 12, 12, 12, 12};
        str expected("[ 12 12 12 12 12 ]");

        auto f{src.begin()}, l{src.end()};
        sa::shell(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting all the elements of an array without repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 3, 4, 7, 6, 1, 5, 8, 10, 9};
        str expected("[ 1 2 3 4 5 6 7 8 9 10 ]");

        auto f{src.begin()}, l{src.end()};
        sa::shell(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting all the elements of an array with repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 7, 4, 7, 6, 8, 5, 8, 10, 2};
        str expected("[ 2 2 4 5 6 7 7 8 8 10 ]");

        auto f{src.begin()}, l{src.end()};
        sa::shell(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting part of the elements of an array without repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 4, 3, 7, 6, 1, 5, 8, 10, 9};
        str expected("[ 2 3 4 6 7 1 5 8 10 9 ]");

        auto f{src.begin()}, l{src.begin() + 5};
        sa::shell(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting part of the elements of an array with repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 7, 4, 7, 6, 8, 5, 8, 10, 2};
        str expected("[ 2 4 6 7 7 8 5 8 10 2 ]");

        auto f{src.begin()}, l{src.begin() + 5};
        sa::shell(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }
}
/// SHELL SORT TEST SUITE

/// MERGE SORT TEST SUITE
TEST_SUITE(">>> Merge Sort Algorithm Test Suite...")
{
    TEST_CASE("Sorting empty array:")
    {
        const type src_sz{0};
        std::array<type, src_sz> src{};
        str expected("[ ]");

        auto f{src.begin()}, l{src.end()};
        sa::merge(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting array of unique elements:")
    {
        const type src_sz{5};
        std::array<type, src_sz> src{12, 12, 12, 12, 12};
        str expected("[ 12 12 12 12 12 ]");

        auto f{src.begin()}, l{src.end()};
        sa::merge(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting all the elements of an array without repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 3, 4, 7, 6, 1, 5, 8, 10, 9};
        str expected("[ 1 2 3 4 5 6 7 8 9 10 ]");

        auto f{src.begin()}, l{src.end()};
        sa::merge(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting all the elements of an array with repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 7, 4, 7, 6, 8, 5, 8, 10, 2};
        str expected("[ 2 2 4 5 6 7 7 8 8 10 ]");

        auto f{src.begin()}, l{src.end()};
        sa::merge(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting part of the elements of an array without repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 4, 3, 7, 6, 1, 5, 8, 10, 9};
        str expected("[ 2 3 4 6 7 1 5 8 10 9 ]");

        auto f{src.begin()}, l{src.begin() + 5};
        sa::merge(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting part of the elements of an array with repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 7, 4, 7, 6, 8, 5, 8, 10, 2};
        str expected("[ 2 4 6 7 7 8 5 8 10 2 ]");

        auto f{src.begin()}, l{src.begin() + 5};
        sa::merge(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }
}
/// MERGE SORT TEST SUITE

/// QUICK SORT TEST SUITE
TEST_SUITE(">>> Quick Sort Algorithm Test Suite...")
{
    TEST_CASE("Sorting empty array:")
    {
        const type src_sz{0};
        std::array<type, src_sz> src{};
        str expected("[ ]");

        auto f{src.begin()}, l{src.end()};
        sa::quick(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting array of unique elements:")
    {
        const type src_sz{5};
        std::array<type, src_sz> src{12, 12, 12, 12, 12};
        str expected("[ 12 12 12 12 12 ]");

        auto f{src.begin()}, l{src.end()};
        sa::quick(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting all the elements of an array without repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 3, 4, 7, 6, 1, 5, 8, 10, 9};
        str expected("[ 1 2 3 4 5 6 7 8 9 10 ]");

        auto f{src.begin()}, l{src.end()};
        sa::quick(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting all the elements of an array with repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 7, 4, 7, 6, 8, 5, 8, 10, 2};
        str expected("[ 2 2 4 5 6 7 7 8 8 10 ]");

        auto f{src.begin()}, l{src.end()};
        sa::quick(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting part of the elements of an array without repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 4, 3, 7, 6, 1, 5, 8, 10, 9};
        str expected("[ 2 3 4 6 7 1 5 8 10 9 ]");

        auto f{src.begin()}, l{src.begin() + 5};
        sa::quick(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting part of the elements of an array with repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{2, 7, 4, 7, 6, 8, 5, 8, 10, 2};
        str expected("[ 2 4 6 7 7 8 5 8 10 2 ]");

        auto f{src.begin()}, l{src.begin() + 5};
        sa::quick(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }
}
/// QUICK SORT TEST SUITE

/// RADIX SORT TEST SUITE
TEST_SUITE(">>> Radix Sort Algorithm Test Suite...")
{
    TEST_CASE("Sorting empty array:")
    {
        const type src_sz{0};
        std::array<type, src_sz> src{};
        str expected("[ ]");

        auto f{src.begin()}, l{src.end()};
        sa::radix(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting array of unique elements:")
    {
        const type src_sz{5};
        std::array<type, src_sz> src{442, 442, 442, 442, 442};
        str expected("[ 442 442 442 442 442 ]");

        auto f{src.begin()}, l{src.end()};
        sa::radix(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting all the elements of an array without repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{12, 884, 802, 43, 1, 579, 44413, 37, 91, 5};
        str expected("[ 1 5 12 37 43 91 579 802 884 44413 ]");

        auto f{src.begin()}, l{src.end()};
        sa::radix(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting all the elements of an array with repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{12, 12, 802, 2468, 1, 579, 2468, 37, 0, 5};
        str expected("[ 0 1 5 12 12 34 579 802 2468 2468 ]");

        auto f{src.begin()}, l{src.end()};
        sa::radix(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting part of the elements of an array without repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{12, 884, 802, 43, 1, 579, 44413, 37, 91, 5};
        str expected("[ 1 12 43 802 884 579 44413 37 91 5 ]");

        auto f{src.begin()}, l{src.begin() + 5};
        sa::radix(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }

    TEST_CASE("Sorting part of the elements of an array with repetition:")
    {
        const type src_sz{10};
        std::array<type, src_sz> src{802, 884, 802, 1, 1, 579, 44413, 37, 91, 5};
        str expected("[ 1 1 802 802 884 579 44413 37 91 5 ]");

        auto f{src.begin()}, l{src.begin() + 5};
        sa::radix(f, l, lt);

        str result(sa::to_string(src.begin(), src.end()));

        CHECK(expected == result);
    }
}
/// RADIX SORT TEST SUITE