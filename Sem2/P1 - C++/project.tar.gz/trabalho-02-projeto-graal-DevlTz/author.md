﻿# Identificação Pessoal

Preencha os dados abaixo para identificar a autoria do trabalho.

- Nome: *<Kauã do Vale Ferreira>*
- Email: *<kkavale27@gmail.com / kaua.vale.632@ufrn.edu.br>*
- Turma: *<P1  - 2024.1 >*

# Questões Finalizadas

- [V] minmax
- [V] reverse
- [V] copy
- [V] find_if
- [ ] all_of
- [ ] any_of
- [ ] none_of
- [ ] equal
- [ ] unique
- [ ] partition

--------
&copy; DIMAp/UFRN 2024.
