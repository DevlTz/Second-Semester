
/*!
 * Several types of sorting algorithms that work on a data range.
 * @author Somebody
 * @date May 1st, 2023.
 * @file sorting.h
 */

#ifndef SORTING_H
#define SORTING_H

#include <sstream>
using std::ostringstream;
#include <iterator>
using std::next;
using std::ostream_iterator;
#include <functional>
using std::function;
using std::less;
#include <vector>
using std::vector;
#include <array>
using std::array;
#include <algorithm>
using std::copy;
using std::for_each;
using std::max_element;
#include <cmath>
using std::pow;
#include <string>
using std::string;
using std::to_string;

namespace sa { // sa = sorting algorithms
/// Prints out the range to a string and returns it to the client.
template <typename FwrdIt> std::string to_string(FwrdIt first, FwrdIt last) {
  std::ostringstream oss;
  oss << "[ ";
  while (first != last) {
    oss << *first++ << " ";
  }
  oss << "]";
  return oss.str();
}

//{{{ RADIX SORT
/*!
 * This function implements the Radix Sorting Algorithm based on the **less
 * significant digit** (LSD).
 *
 * @note There is no need for a comparison function to be passed as argument.
 *
 * @param first Pointer/iterator to the beginning of the range we wish to sort.
 * @param last Pointer/iterator to the location just past the last valid value
 * of the range we wish to sort.
 * @tparam FwrdIt A forward iterator to the range we need to sort.
 * @tparam Comparator A Comparator type function tha returns true if first
 * argument is less than the second argument.
 */

// [1] Determine how many digits the largest integer in the incoming range
// has.
// size_t n_digits{0};
// [2] Traverse the entire range 'n_digits' times, from the less significant
// to the most significant (i.e. from left to right).
// for (size_t i{0}; i < n_digits; ++i) {
// [a]=== Buckets creation.
// We create the 10 buckets each iteration so that they start empty every
// time through.

// [b]=== Range traversal and values distriburion into buckets.
// For each value of the range we need to examine i-th less significant
// digit so that we can assign the value to the corresponding bucket.

// ==============================================================
// What the for_each above does is:
// --------------------------------------------------------------
// Assuming value=123 and that the largest number in the collection has 4
// digits. 1st pass: 123/1 = 123; 123 % 10 = 3. buckets[3].push_back(123).
// 2nd pass: 123/10 = 12; 12 % 10 = 2.  buckets[2].push_back(123).
// 3rd pass: 123/100 = 1; 1 % 10 = 1.   buckets[1].push_back(123).
// 4th pass: 123/1000 = 0; 0 % 10 = 0.  buckets[0].push_back(123).

// [c]=== Reverse movement from buckets back into range.
// At the end of the traversal, we copy all values from the buckets
// back to the original range. They naturally come in ascending order
// considering the current i-th digit.
// Points to the location in memory where the values should be copied to.
// For each bucket...
// ... copy the bucket's stored values back into the range, and
// ...at the same time, update the destination pointer for the next
// iteration.
// for to traverse the digits.

//}}} RADIX SORT

template <typename DataType> 
void radix(DataType *first, DataType *last) {
  if (first >= last)
    return;

  // Find the maximum number to know the number of digits
  DataType max_val = *std::max_element(first, last);
  int max_digits = 0;
  while (max_val != 0) {
    max_val /= 10;
    ++max_digits;
  }

  // Perform counting sort for every digit
  for (int exp = 1; max_digits > 0; exp *= 10, --max_digits) {
    std::vector<std::vector<DataType>> buckets(10);

    // Distribute the elements into buckets
    for (DataType *it = first; it != last; ++it) {
      int digit = (*it / exp) % 10;
      buckets[digit].push_back(*it);
    }

    // Collect the elements from the buckets back into the original range
    DataType *it = first;
    for (auto &bucket : buckets) {
      for (auto &val : bucket) {
        *it++ = val;
      }
    }
  }
}
//{{{ INSERTION SORT

template <typename DataType, typename Compare>
void insertion(DataType *first, DataType *last, Compare cmp) {
  for (auto it = first; it != last; ++it) {
    auto val = *it;
    auto *insert_pos = it;

    while (insert_pos != first && cmp(val, *std::prev(insert_pos))) {
      *insert_pos = *std::prev(insert_pos);
      --insert_pos;
    }
    *insert_pos = val;
  }
}
//}}} INSERTION SORT

//{{{ SELECTION SORT
template <typename DataType, typename Compare>
void selection(DataType *first, DataType *last, Compare cmp) {
  int size = last - first;
  // Loop para percorrer cada posição onde o menor/maior elemento será colocado
  for (int currentIndex = 0; currentIndex < size - 1; ++currentIndex) {
    // Assume que o menor/maior elemento está na posição atual
    int bestIndex = currentIndex;
    // Busca pelo menor/maior elemento no restante do array
    for (int searchIndex = currentIndex + 1; searchIndex < size;
         ++searchIndex) {
      if (cmp(first[searchIndex], first[bestIndex])) {
        bestIndex = searchIndex; // Atualiza o índice do menor/maior elemento
      }
    }
    // Troca o elemento da posição atual com o menor/maior encontrado
    if (bestIndex != currentIndex) {
      std::swap(first[currentIndex], first[bestIndex]);
    }
  }
}
//}}} SELECTION SORT

//{{{ BUBBLE SORT
template <typename DataType, typename Compare>
void bubble(DataType *first, DataType *last, Compare cmp) {
  for (DataType *i = first; i < last; ++i) {
    for (DataType *j = first; j < last - 1; ++j) {
      if (cmp(*(j + 1), *j)) {
        std::swap(*j, *(j + 1));
      }
    }
  }
}
//}}} BUBBLE SORT

//{{{ SHELL SORT
template <typename DataType, typename Compare>
void shell(DataType *first, DataType *last, Compare cmp) {
  if (first >= last)
    return;
  // Calcula o tamanho do array
  int size = last - first;
  // Sequência de gaps
  for (int gap = size / 2; gap > 0; gap /= 2) {
    // Para cada gap, faz o insertion sort nos elementos separados pelo gap
    for (int i = gap; i < size; i++) {
      DataType temp = first[i];
      int j = i;
      // Move elementos maiores que temp para frente
      while (j >= gap && cmp(temp, first[j - gap])) {
        first[j] = first[j - gap];
        j -= gap;
      }
      // Coloca temp na posição correta
      first[j] = temp;
    }
  }
}
//}}} SHELL SORT
//{{{ MERGE SORT

template <typename DataType, typename Compare>
void mergesort(DataType *first, DataType *last, Compare cmp) {
  auto n = std::distance(first, last);
  if (n <= 1) {
    return;
  }

  auto middle = first + n / 2;

  mergesort(first, middle, cmp);
  mergesort(middle, last, cmp);

  auto left_size = std::distance(first, middle);
  auto right_size = std::distance(middle, last);

  DataType *left = new DataType[left_size];
  DataType *right = new DataType[right_size];

  std::copy(first, middle, left);
  std::copy(middle, last, right);

  auto left_it = left;
  auto right_it = right;
  auto dest_it = first;

  while (left_it < left + left_size && right_it < right + right_size) {
    if (cmp(*right_it, *left_it)) {
      *dest_it++ = *right_it++;
    } else {
      *dest_it++ = *left_it++;
    }
  }

  std::copy(left_it, left + left_size, dest_it);
  std::copy(right_it, right + right_size, dest_it);

  delete[] left;
  delete[] right;
}

//}}} MERGE SORT

//{{{ QUICK SORT
/// Quick sort implementation.
template <typename DataType, typename Compare>
void quick(DataType *first, DataType *last, Compare cmp) {
  // Verifica se o intervalo tem mais de um elemento
  if (first >= last)
    return;
  // Define o pivô
  DataType *pivot = last - 1;
  DataType *i = first;
  // Particiona o array em torno do pivô
  for (DataType *j = first; j < pivot; ++j) {
    if (cmp(*j, *pivot)) {
      std::swap(*i, *j);
      ++i;
    }
  }
  // Coloca o pivô na posição correta
  std::swap(*i, *pivot);
  // Chama recursivamente o Quick Sort para as listas
  quick(first, i, cmp);    // Lista esquerda
  quick(i + 1, last, cmp); // Lista direita
}
//}}} QUICK SORT
};     // namespace sa
#endif // SORTING_H
